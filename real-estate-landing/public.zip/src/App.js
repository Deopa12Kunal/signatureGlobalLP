import React from "react";
import RealEstateLanding from "../src/components/RealEstateLanding";

function App() {
  return (
    <div className="App">
      <RealEstateLanding />
    </div>
  );
}

export default App;
