import React from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { submitContactForm } from "../services/firebase";

const ContactForm = () => {
  const contactSchema = yup.object({
    name: yup.string().required("Name is required"),
    email: yup.string().email("Invalid email").required("Email is required"),
    message: yup
      .string()
      .min(10, "Message too short")
      .required("Message is required"),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(contactSchema),
  });

  const onSubmit = async (data) => {
    console.log("Submitting form data:", data); // Debug log
    try {
      const docId = await submitContactForm(data);
      console.log("Submission successful, doc ID:", docId); // Debug log
      alert("Form submitted successfully!");
      reset();
    } catch (error) {
      console.error("Submission error:", error); // Debug log
      alert("Submission failed. Please try again.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <input
          {...register("name")}
          placeholder="Name"
          className="w-full p-2 border rounded"
        />
        {errors.name && (
          <p className="text-red-500 text-sm">{errors.name.message}</p>
        )}
      </div>

      <div>
        <input
          {...register("email")}
          placeholder="Email"
          className="w-full p-2 border rounded"
        />
        {errors.email && (
          <p className="text-red-500 text-sm">{errors.email.message}</p>
        )}
      </div>

      <div>
        <textarea
          {...register("message")}
          placeholder="Message"
          className="w-full p-2 border rounded h-32"
        />
        {errors.message && (
          <p className="text-red-500 text-sm">{errors.message.message}</p>
        )}
      </div>

      <button
        type="submit"
        className="w-full bg-black text-white py-2 rounded hover:bg-opacity-90"
      >
        Send Message
      </button>
    </form>
  );
};

export default ContactForm;
