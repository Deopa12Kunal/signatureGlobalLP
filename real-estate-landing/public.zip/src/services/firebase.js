import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export const submitContactForm = async (formData) => {
    console.log("Firestore Config:", {
      projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
      collection: "contact_submissions",
      data: formData,
    });
  try {
    const docRef = await addDoc(collection(db, "contact_submissions"), {
      ...formData,
      timestamp: serverTimestamp(),
      source: window.location.hostname,
    });
    return docRef.id;
  } catch (error) {
    console.error("Form Submission Error:", error);
    throw error;
  }
};

export const fetchProperties = async () => {
  try {
    const propertiesCollection = collection(db, "properties");
    // Implement fetch logic
  } catch (error) {
    console.error("Fetch Properties Error:", error);
    throw error;
  }
};
